// abstract mini game to be extended

public abstract class MiniGame {

    protected int _difficulty;

    public abstract boolean play( Player player );

}
