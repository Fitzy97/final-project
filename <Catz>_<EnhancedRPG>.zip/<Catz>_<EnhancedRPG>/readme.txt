1.  Compile everything.
2.  $ java Catz
